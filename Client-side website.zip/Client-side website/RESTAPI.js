let categoriesMap = {}; // To map category_id to category_name

// Fetch and display the list of active categories on the home page
function fetchCategories() {
    fetch('http://localhost:3000/api/categories')
        .then(response => response.json())
        .then(categories => {
            const categoriesList = document.getElementById('categories-list');
            categoriesList.innerHTML = ''; // Clear existing content

            // Create a map of category_id to category_name for easier lookup later
            categories.forEach(category => {
                categoriesMap[category.id] = category.name; // Store in the map
                const categoryDiv = document.createElement('div');
                categoryDiv.classList.add('category');
                categoryDiv.innerHTML = `<h3>${category.name}</h3>`;
                categoriesList.appendChild(categoryDiv);
            });

            // Once categories are fetched, fetch the fundraisers
            fetchFundraisers();
        })
        .catch(error => {
            console.error('Error fetching categories:', error);
            const errorMessage = document.createElement('p');
            errorMessage.style.color = 'red';
            errorMessage.textContent = 'Error fetching categories. Please try again later.';
            document.getElementById('categories-list').appendChild(errorMessage);
        });
}

// Fetch and display the list of active fundraisers on the home page
function fetchFundraisers() {
    fetch('http://localhost:3000/api/fundraisers')
        .then(response => response.json())
        .then(fundraisers => {
            const fundraisersList = document.getElementById('fundraisers-list');
            fundraisersList.innerHTML = ''; // Clear existing content
            fundraisers.forEach(fundraiser => {
                const fundraiserDiv = document.createElement('div');
                fundraiserDiv.classList.add('fundraiser');

                // Use the categoriesMap to find the category name for this fundraiser
                const categoryName = categoriesMap[fundraiser.category_id] || 'Unknown Category';

                fundraiserDiv.innerHTML = `
                    <h3>${fundraiser.caption}</h3>
                    <p>Organizer: ${fundraiser.organizer}</p>
                    <p>Target Funding: ${fundraiser.target_funding} AUD</p>
                    <p>Current Funding: ${fundraiser.current_funding} AUD</p>
                    <p>City: ${fundraiser.city}</p>
                    <p>Category: ${categoryName}</p>
                    <a href="fundraiser.html?id=${fundraiser.id}">View Details</a>
                `;
                fundraisersList.appendChild(fundraiserDiv);
            });
        })
        .catch(error => {
            console.error('Error fetching fundraisers:', error);
            const errorMessage = document.createElement('p');
            errorMessage.style.color = 'red';
            errorMessage.textContent = 'Error fetching fundraisers. Please try again later.';
            document.getElementById('fundraisers-list').appendChild(errorMessage);
        });
}
// Fetch details for a specific fundraiser
function fetchFundraiserDetails() {
    const params = new URLSearchParams(window.location.search);
    const id = params.get('id');

    fetch(`http://localhost:3000/api/fundraiser/${id}`)
        .then(response => response.json())
        .then(fundraiser => {
            document.getElementById('fundraiser-caption').textContent = fundraiser.caption;
            document.getElementById('fundraiser-organizer').textContent = fundraiser.organizer;
            document.getElementById('fundraiser-target').textContent = fundraiser.target_funding + ' AUD';
            document.getElementById('fundraiser-current').textContent = fundraiser.current_funding + ' AUD';
            document.getElementById('fundraiser-city').textContent = fundraiser.city;
            document.getElementById('fundraiser-category').textContent = categoriesMap[fundraiser.category_id] || 'Unknown Category';
        })
        .catch(error => {
            console.error('Error fetching fundraiser details:', error);
            const errorMessage = document.createElement('p');
            errorMessage.style.color = 'red';
            errorMessage.textContent = 'Error fetching fundraiser details. Please try again later.';
            document.getElementById('fundraiser-details').appendChild(errorMessage);
        });
}
// Fetch and populate the categories dropdown in the search form
function fetchCategories() {
    fetch('http://localhost:3000/api/categories')
        .then(response => response.json())
        .then(categories => {
            const categorySelect = document.getElementById('category');
            categories.forEach(category => {
                const option = document.createElement('option');
                option.value = category.id;
                option.textContent = category.name;
                categorySelect.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Error fetching categories:', error);
        });
}

// Handle search form submission
document.getElementById('search-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const organizer = document.getElementById('organizer').value;
    const city = document.getElementById('city').value;
    const category = document.getElementById('category').value;

    // Build query string based on form inputs
    let queryParams = '?';
    if (organizer) queryParams += `organizer=${organizer}&`;
    if (city) queryParams += `city=${city}&`;
    if (category) queryParams += `category=${category}`;

    // Fetch fundraisers based on search criteria
    fetch(`http://localhost:3000/api/search${queryParams}`)
        .then(response => response.json())
        .then(fundraisers => {
            const resultsDiv = document.getElementById('search-results');
            resultsDiv.innerHTML = ''; // Clear previous results
            if (fundraisers.length === 0) {
                resultsDiv.innerHTML = '<p style="color:red">No fundraisers found matching the criteria</p>';
            } else {
                fundraisers.forEach(fundraiser => {
                    const fundraiserDiv = document.createElement('div');
                    fundraiserDiv.classList.add('fundraiser');

                    // Get category name from the category dropdown options
                    const categoryName = categoriesMap[fundraiser.category_id] || 'Unknown Category';

                    fundraiserDiv.innerHTML = `
                        <h3>${fundraiser.caption}</h3>
                        <p>Organizer: ${fundraiser.organizer}</p>
                        <p>City: ${fundraiser.city}</p>
                        <p>Category: ${categoryName}</p>
                        <a href="fundraiser.html?id=${fundraiser.id}">View Details</a>
                    `;
                    resultsDiv.appendChild(fundraiserDiv);
                });
            }
        })
        .catch(error => {
            console.error('Error during search:', error);
            const errorMessage = document.createElement('p');
            errorMessage.style.color = 'red';
            errorMessage.textContent = 'Error during search. Please try again later.';
            document.getElementById('search-results').appendChild(errorMessage);
        });
});

// Clear form inputs
function clearCheckboxes() {
    document.getElementById('organizer').value = '';
    document.getElementById('city').value = '';
    document.getElementById('category').value = '';
}
